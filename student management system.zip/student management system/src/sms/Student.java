package sms;

public class Student {
    int number;
    double Score_Math,Score_English,Score_Java,Score_System,Score_PE,Score_Average;
    String name;
    public void Student(){}
    public void Student(String name,int number,double Score_Math,double Score_English,double Score_Java,double Score_System,double Score_PE,double Score_Average){
        this.name=name;
        this.number=number;
        this.Score_English=Score_English;
        this.Score_Java=Score_Java;
        this.Score_Math=Score_Math;
        this.Score_PE=Score_PE;
        this.Score_System=Score_System;
        this.Score_Average=Score_Average;
    }
    public void Student(String name,int number,double Score_Math,double Score_English,double Score_Java,double Score_System,double Score_PE){
        this.name=name;
        this.number=number;
        this.Score_English=Score_English;
        this.Score_Java=Score_Java;
        this.Score_Math=Score_Math;
        this.Score_PE=Score_PE;
        this.Score_System=Score_System;
        this.Score_Average=(Score_English+Score_Java+Score_Math+Score_PE+Score_System)/5;
    }

}
